package cn.sensevision.app.device.service;

import cn.sensevision.app.device.model.CameraModel;
import com.github.pagehelper.PageInfo;
import java.util.List;

public interface CameraService {


    /**
     * 更新用户
     *
     * @param cameraModel
     * @return
     */
    int updateCamera(CameraModel cameraModel);

    /**
     * 分页查询
     *
     * @param cameraModel 对象
     * @return 对象列表
     */
    PageInfo<CameraModel> pageQuery(CameraModel cameraModel);

    /**
     * 通过实体作为筛选条件查询
     *
     * @param cameraModel 实例对象
     * @return 对象列表
     */
    List<CameraModel> queryAll(CameraModel cameraModel);
}


