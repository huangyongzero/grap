package cn.sensevision.app.device.service.impl;

import cn.sensevision.app.device.dao.CameraDao;
import cn.sensevision.app.device.model.CameraModel;
import cn.sensevision.app.device.service.CameraService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;


@Service
public class CameraServiceImpl implements CameraService {
    @Resource
    private CameraDao cameraDao;

    @Override
    public int updateCamera(CameraModel cameraModel) {
        return cameraDao.updateCamera(cameraModel);
    }


    /**
     * 分页查询
     *
     * @param cameraModel 对象
     * @return 对象列表
     */
    @Override
    public PageInfo<CameraModel> pageQuery(CameraModel cameraModel) {
        PageHelper.startPage(cameraModel.getOffset(), cameraModel.getLimit());
        List<CameraModel> lists=cameraDao.queryAll(cameraModel);
        PageInfo<CameraModel> pageInfo=new PageInfo<>(lists);
        return pageInfo;
    }
    /**
     * 根据参数查询多条数据
     *
     * @param cameraModel 对象
     * @return 对象列表
     */
    @Override
    public List<CameraModel> queryAll(CameraModel cameraModel) {
        return cameraDao.queryAll(cameraModel);
    }



}


