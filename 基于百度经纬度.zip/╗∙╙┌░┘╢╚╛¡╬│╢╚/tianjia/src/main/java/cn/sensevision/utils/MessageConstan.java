package cn.sensevision.utils;

/**
 * 静态变量及说明
 *
 * @Author weideng
 * @CLassName MessageConstan
 * @Date 2018/10/29 17:03
 **/
public class MessageConstan {


    /**
     * 返回成功标识
     */
    public static final Integer OK = 0;

    /**
     * 用户或者密码错误
     * 10开头
     */
    public static final Integer UNAME_PWD_ERROR = 1001;


    /**
     * 返回登录成功信息
     * 用户相关
     * 9xx
     */
    public static final Integer LOGIN_SUCCESS = 900;

    /**
     * 返回登录失败信息
     * 用户相关
     * 9xx
     */
    public static final Integer LOGIN_FAILD = 901;

    /**
     * 用户名已存在
     * 用户相关
     * 9xx
     */
    public static final Integer USER_IS_EXIST = 902;

    /**
     * 绑定异常
     * 用户相关
     * 9xx
     */
    public static final Integer BIND_EXCEPTION = 903;

    /**
     * 设备已存在
     * 用户相关
     * 9xx
     */
    public static final Integer DEV_IS_EXIST = 904;

    /**
     * 设备已经被绑定请先解绑
     * 用户相关
     * 9xx
     */
    public static final Integer DEV_IS_BIND = 905;



    /**
     * 系统错误
     * -1
     */
    public static final Integer SYSTEM_ERROR = -1;

    /**
     * 参数错误
     * -2
     */
    public static final Integer PARAMS_ERROR = -2;


    /**
     * 添加
     * 2xxx
     */
    public static final Integer ADD_FIELD = 2001;

    /**
     * 查询失败
     * 2xxx
     */
    public static final Integer SEARCH_FIELD = 2002;

    /**
     * 修改失败
     * 2xxx
     */
    public static final Integer UPDATE_FIELD = 2003;

    /**
     * 删除失败
     * 2xxx
     */
    public static final Integer DELETE_FIELD = 2004;


    /**
     * token遗失
     * 6xx开头
     */
    public static final Integer TOKEN_LOSE = 601;

    /**
     * token过期
     * 6xx开头
     */
    public static final Integer TOKEN_PAST_DUE = 602;

    /**
     * token无效、错误
     * 6xx开头
     */
    public static final Integer TOKEN_INVALIDITY = 603;


    /**
     * 无权限
     * 7xx开头
     */
    public static final Integer ROLE_NONE = 701;

    /**
     * ES相关
     * 8xx开头
     */
    public static final Integer ES_COUNT = 801;

    /**
     * ES相关
     * 8xx开头
     */
    public static final Integer ES_INEXISTENCE = 802;


}
