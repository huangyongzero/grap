package cn.sensevision.utils;

/**
 * 组装es请求
 * @Author weideng
 * @CLassName BulkHelper
 * @Date 2019/3/19 21:20
**/
public class BulkHelper {

    private static String indexFmt = "{ \"index\" : { \"_index\" : \"ahst-cameras\", \"_type\" : \"ahst-cameras\", \"_id\" : \"${id}\" } }";

    public static String getIndexHeaer(String id) {
        return indexFmt.replace("{id}", id );
    }

    public static StringBuffer bulkCache = new StringBuffer();

    public static void bulkAdd(String id, String json) {
        bulkCache.append(getIndexHeaer(id))
                .append("\n")
                .append(json)
                .append("\n");
    }

    public static String bulkString() {
        return bulkCache.toString();
    }

    public static void clear() {
        bulkCache = new StringBuffer();
    }

}
