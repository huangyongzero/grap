package cn.sensevision.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
/**
 * 返回错误堆栈信息
 * @Author weideng
 * @CLassName LoggerUtils
 * @Date 2018/9/1 08:45
**/
public class LoggerUtils {

    /**
     * 获取错误的堆栈信息
     * @param throwable
     * @return
     */
    public static String getStackTrace(Throwable throwable){
        StringWriter stringWriter=new StringWriter();
        PrintWriter printWriter=new PrintWriter(stringWriter);

        try {
            throwable.printStackTrace(printWriter);
            return stringWriter.toString();
        }finally {
            printWriter.close();
        }

    }

}
