package cn.sensevision.app.device.dao;

import cn.sensevision.app.device.model.CameraModel;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface CameraDao {

    /**
     * 更新用户
     *
     * @param cameraModel
     * @return
     */
    int updateCamera(CameraModel cameraModel);

    /**
     * 分页查询
     *
     * @param offset 查询起始位置
     * @param limit  查询条数
     * @return 对象列表
     */
     PageInfo<CameraModel> pageQuery(@Param("offset") int offset, @Param("limit") int limit, @Param("cameraModel") CameraModel cameraModel);

    /**
     * 通过实体作为筛选条件查询
     *
     * @param  cameraModel 实例对象
     * @return 对象列表
     */
    List<CameraModel> queryAll(CameraModel cameraModel);
}




