package cn.sensevision.app.device.ctrl;

import cn.sensevision.app.device.model.CameraModel;
import cn.sensevision.app.device.service.CameraService;
import cn.sensevision.data.db.ResultMap;
import cn.sensevision.utils.JsonMessageUtils;
import cn.sensevision.utils.LoggerUtils;
import cn.sensevision.utils.MessageConstan;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.Map;

/**
 * @Author huangyong
 * @CLassName CameraController
 * @Date 2019/6/17
 */


@RestController
@RequestMapping("/device")
public class CameraController {
    private static final Logger LOGGER=LoggerFactory.getLogger(CameraController.class);

    @Resource
    private ResultMap resultMap;

    @Resource
    private CameraService cameraService;

    /**
     * 摄像头更新
     *
     * @param body
     * @return
     */
    @RequestMapping(value="/updateCamera", method=RequestMethod.POST)
    @ResponseBody
    public
    Map updateCamera(@RequestBody String body) {
        try {
            CameraModel cameraModel=JSON.parseObject(body, CameraModel.class);
            return JsonMessageUtils.message(MessageConstan.OK, cameraService.updateCamera(cameraModel), "ok");
        } catch (Exception e) {
            LoggerUtils.getStackTrace(e.fillInStackTrace());
            return JsonMessageUtils.message(MessageConstan.PARAMS_ERROR, null, "参数异常");
        }
    }


    /**
     * 分页查询
     *
     * @param jsonParas 对象
     * @return 分页数据
     */
    @RequestMapping(value="/pageQuery",method=RequestMethod.POST)
    @ResponseBody
    public
    ResultMap pageQuery(@RequestBody String jsonParas) throws Exception {
        System.out.println(jsonParas);
        CameraModel cameraModel = JSON.parseObject(jsonParas,CameraModel.class);
        return resultMap.success().code(200).message(cameraService.pageQuery(cameraModel));
    }

    /**
     * 根据条件查询所有数据
     *
     * @param cameraModel 对象
     * @return 数据
     */
    @RequestMapping(value="/queryAll",method=RequestMethod.POST)
    @ResponseBody
    public
    ResultMap queryAll(CameraModel cameraModel) throws Exception {
        System.out.println(111);
        return resultMap.success().code(200).message(cameraService.queryAll(cameraModel));
    }


}
