package cn.sensevision.data.db;

import org.springframework.stereotype.Component;

import java.util.HashMap;

/**
 * 接口返回对象
 *
 * @Author weideng
 * @CLassName ResultMap
 * @Date 2019/3/4 23:10
 **/
@Component
public class ResultMap extends HashMap<String, Object> {
    public ResultMap() {
    }

    public ResultMap success() {
        this.put("resultMsg", "success");
        return this;
    }

    public ResultMap fail() {
        this.put("resultMsg", "fail");
        return this;
    }

    public ResultMap fail(Object msg) {
        this.put("resultMsg", msg);
        return this;
    }

    public ResultMap success(Object msg) {
        this.put("resultMsg", msg);
        return this;
    }

    public ResultMap message(Object message) {
        this.put("data", message);
        return this;
    }

    public ResultMap code(int code) {
        this.put("resultCode", code);
        return this;
    }
}

