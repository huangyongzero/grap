package cn.sensevision.comms;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * Swagger2
 * @Author weideng
 * @CLassName Swagger2
 * @Date 2018/5/31 13:54
**/
@Configuration
public class Swagger2 {

    @Value("${scan.package.swagger2}")
    private String SCANPACKAGE ;

    @Bean
    public Docket createRestApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage(SCANPACKAGE))
                .paths(PathSelectors.any())
                .build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("智慧110后台接口文档")
                .description("大屏管理后台接口文档")
                .termsOfServiceUrl("")
                .version("1.0")
                .build();
    }
}
