package cn.sensevision.data.db;

import com.alibaba.druid.support.http.WebStatFilter;

import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;


/**
 * 配置监控拦截器
 * Druid监控链接器
 * @Author weideng
 * @CLassName DruidStatFitler
 * @Date 2018/4/16 11:34
**/
@WebFilter(filterName="druidWebStatFilter",
        urlPatterns="/*",
        initParams={
                @WebInitParam(name="exclusions",value="*.js,*.gif,*.jpg,*.bmp,*.png,*.css,*.ico,/druid/*"),// 忽略资源
        })
public class DruidStatFitler extends WebStatFilter {

}