package cn.sensevision;

import org.apache.commons.io.FileUtils;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;

/**
 * 程序入口
 *
 * @author weideng
 * @date 2018/3/27 22:27
 */
@MapperScan("cn.sensevision.app.*.dao")
@SpringBootApplication
@ServletComponentScan
@EnableSwagger2
public class InitApplication {


    private static final Logger LOGGER = LoggerFactory.getLogger(InitApplication.class);

    /**
     * 保存pid到文件
     *
     * @param pid
     */
    public static void storePid(String pid) {
        File file = new File(InitApplication.class.getClassLoader().getResource("app.pid").getFile());
        try {
            FileUtils.writeStringToFile(file, pid);
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    /**
     * 获取存储的pid信息
     *
     * @return
     */
    public static String getPid() {
        String pid = null;
        File file = new File(InitApplication.class.getClassLoader().getResource("app.pid").getFile());
        try {
            pid = FileUtils.readFileToString(file);
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return pid;
    }

    public static void main(String[] args) {

        String pidName = ManagementFactory.getRuntimeMXBean().getName();

        storePid(pidName.substring(0, pidName.indexOf("@")));
        LOGGER.info("服务开始启动，当前进程号为：{}", getPid());

        //程序入口
        SpringApplication.run(InitApplication.class, args);

    }


}
