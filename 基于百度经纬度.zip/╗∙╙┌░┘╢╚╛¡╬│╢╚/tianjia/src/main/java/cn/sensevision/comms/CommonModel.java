package cn.sensevision.comms;

/**
 * 通用模型对象，封装常用属性
 * @Author weideng
 * @CLassName CommonModel
 * @Date 2018/5/31 13:32
**/
public class CommonModel {
	
	/*********查询属性*************/
	/**分页：页码*/
	private Integer page;
	/**分页：每页记录数*/
	private Integer rows;
	/**排序方式:asc升序,desc降序*/
	private String sord;
	
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Integer getRows() {
		return rows;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		this.sord = sord;
	}
}
