package cn.sensevision.utils;

import java.util.HashMap;
import java.util.Map;

import com.github.pagehelper.Page;

/**
 * jqgrid分页工具类
 * @Author weideng
 * @CLassName JqGridPageUtil
 * @Date 2018/5/31 13:34
**/
public class JqGridPageUtil {
	
	/**
	 * 创建分页信息(mybatis分页插件专用)
	 * 
	 * @param queryResult 分页查询结果
	 * 
	 * @return 分页结果map
	 */
	
	public static Map createPageInfo(Object queryResult){
		Page page = (Page)queryResult;
		Map<String, Object> pageMap = new HashMap<String, Object>();
		//当前页
		pageMap.put("page", page == null ? 0 : page.getPageNum());
		//总页数
		pageMap.put("total", page == null ? 0 : page.getPages());
		//总记录数
		pageMap.put("records", page == null ? 0 : page.getTotal());
		//记录集合
		pageMap.put("rows", page == null ? "" : page.getResult());
		return pageMap;
	}
	
}
