package cn.sensevision;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * 初始化类
 *
 * @Author weideng
 * @CLassName ApplicationStartup
 * @Date 2019/3/19 22:34
 **/
@Component
public class ApplicationStartup implements CommandLineRunner {


    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationStartup.class);


    @Override
    public void run(String... args) {

        LOGGER.info("平台启动成功。");
    }
}
