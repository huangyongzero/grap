package cn.sensevision.utils;

import java.io.*;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 文件操作
 * @Author weideng
 * @CLassName FileUtils
 * @Date 2018/5/31 13:34
**/
public class FileUtils {


    /**
     * 保存文件
     *
     * @param filePath
     * @param is
     * @author
     */
    public static boolean saveFile(String filePath, InputStream is) {
        OutputStream os = null;
        boolean operator = true;
        try {
            File file = createFile(filePath);
            os = new FileOutputStream(file);
            int byteCount;
            byte[] buf = new byte[1024];
            while ((byteCount = is.read(buf)) != -1) {
                os.write(buf, 0, byteCount);
            }
        } catch (Exception e) {
            operator = false;
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
                if (os != null) {
                    os.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return operator;
    }

    /**
     * B方法追加文件：使用FileWriter
     */
    public static void appendMethod(String fileName, String content) {
        try {
            //打开一个写文件器，构造函数中的第二个参数true表示以追加形式写文件
            FileWriter writer = new FileWriter(fileName, true);
            writer.write(content);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * 创建文件夹
     *
     * @param filePath
     * @return
     * @throws IOException
     * @author
     */
    private static File createFile(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            File pFile = file.getParentFile();
            if (!pFile.exists()) {
                pFile.mkdirs();
            }

            file.createNewFile();
        }
        return file;
    }


    /**
     * 删除文件
     *
     * @param filePath
     * @author ybzhu
     */
    public static void deleteFile(String filePath) throws IOException {
        File file = new File(filePath);
        file.delete();
    }

    /**
     * 文件上传
     *
     * @param file
     * @param fileName
     * @throws Exception
     */
    public static void uploadFile(byte[] file,String filePath,String fileName) throws Exception {

        File targetFile = new File(filePath);
        if(!targetFile.exists()){
            targetFile.mkdirs();
        }
        FileOutputStream out = new FileOutputStream(filePath+fileName);
        out.write(file);
        out.flush();
        out.close();
    }



}
