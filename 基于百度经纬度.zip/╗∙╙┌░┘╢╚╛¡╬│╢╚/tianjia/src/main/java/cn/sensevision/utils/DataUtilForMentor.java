package cn.sensevision.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DataUtilForMentor {
	public static String YMDFrmat(long data){
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date dt = new Date(data);
		
		return format.format(dt);
	}
	public static String YMDFrmat(String data){
		SimpleDateFormat format = new SimpleDateFormat("hh:mm:ss");
		String date =  data+" " +format.format(new Date());
		return date;
	}
	public static void main(String[] args) {
		String date = "2007-07-19";
		System.out.println(YMDFrmat(date));
		
		SimpleDateFormat format = new SimpleDateFormat("hh:mm:ss");
		System.out.println(format.format(new Date()));
		
	}
}
