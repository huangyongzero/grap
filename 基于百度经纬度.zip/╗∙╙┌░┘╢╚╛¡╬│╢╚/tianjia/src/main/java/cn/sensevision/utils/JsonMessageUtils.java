package cn.sensevision.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * 消息返回模板
 *
 * @Author weideng
 * @CLassName JsonMessageUtils
 * @Date 2018/10/29 16:38
**/
public class JsonMessageUtils {

    /**
     *
     *返回数据模板
     *
     * @param resultCode 返回code
     * @param datas  返回数据
     * @param resultMsg  返回错误消息
     * @return
     */
    public static Map message(Integer resultCode,Object datas,String resultMsg){
        Map map = new HashMap();
        map.put("resultCode",resultCode);
        if(datas != null){
            map.put("data",datas);
        }
        map.put("resultMsg",resultMsg);
        return map;
    }

}
