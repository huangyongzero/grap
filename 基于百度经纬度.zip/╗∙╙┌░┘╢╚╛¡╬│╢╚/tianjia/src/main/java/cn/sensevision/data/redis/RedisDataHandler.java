package cn.sensevision.data.redis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.*;

/**
 * redis数据处理接口 方便后期拓展
 * @Author David
 * @Date 2017/3/17 20:30
 */
@Component
public class RedisDataHandler {

	@Autowired
	private  JedisPool jedisPool = null;

	@Value("${redis.server.dbid}")
	private int redis_server_dbid ;

	public  void hMset(final String key, final Map<String, String> map) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		jedis.hmset(key.getBytes(), fromStringToByte(map));
		jedis.close();
	}

	@SuppressWarnings("unchecked")
	public  Map<String, String> hGetAll(final String key) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		Map<String, String> map = fromByteToString(jedis.hgetAll(key.getBytes()));
		jedis.close();
		return map;
	}

	public  void sAdd(final String key, final String value) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		jedis.sadd(key.getBytes(), value.getBytes());
		jedis.close();
	}

	@SuppressWarnings("unchecked")
	public  Set<String> sMembers(final String key) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		Set<byte[]> set = jedis.smembers(key.getBytes());
		jedis.close();
		return fromByteToString(set);
	}

	public  boolean keyExists(final String key) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		boolean exists = jedis.exists(key.getBytes());
		jedis.close();
		return exists;
	}

	public  void delKey(final String key) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		jedis.del(key.getBytes());
		jedis.close();
	}

	private  Set<String> fromByteToString(Set<byte[]> set) {
		Set<String> resultSet = new HashSet<String>();
		for (byte[] value : set) {
			resultSet.add(new String(value));
		}
		return resultSet;
	}

	private  Map<byte[], byte[]> fromStringToByte(Map<String, String> map) {
		Map<byte[], byte[]> resultMap = new HashMap<byte[], byte[]>();
		Set<String> keySet = map.keySet();
		for (String key : keySet) {
			String value = map.get(key);
			resultMap.put(key.getBytes(), value.getBytes());
		}
		return resultMap;
	}

	private  Map<String, String> fromByteToString(Map<byte[], byte[]> map) {
		Map<String, String> resultMap = new HashMap<String, String>();
		Set<byte[]> keySet = map.keySet();
		for (byte[] key : keySet) {
			String value = new String(map.get(key));
			String keyStr = new String(key);
			resultMap.put(keyStr, value);
		}
		return resultMap;
	}

	public  boolean hkeyExist(final String key, final String hkey) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		boolean exists = jedis.hexists(key.getBytes(), hkey.getBytes());
		jedis.close();
		return exists;
	}

	public  String hget(final String key, final String hkey) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		byte[] val = jedis.hget(key.getBytes(), hkey.getBytes());
		jedis.close();
		if(val == null || val.length == 0){
			return null;
		}
		return new String(val);
	}

	public  String get(final String key) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		byte[] val = jedis.get(key.getBytes());
		jedis.close();
		if(val == null || val.length == 0){
			return null;
		}
		return new String(val);
	}

	public  String set(final String key,final String value) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		String val = jedis.set(key,value);
		jedis.close();
		if(val == null || val == "" ){
			return null;
		}
		return val;
	}

	public  Boolean hset(final String key, final String hkey, final String hval) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		Long rel = jedis.hset(key.getBytes(), hkey.getBytes(), hval.getBytes());
		jedis.close();
		return rel != null ? rel == 1 : null;
	}

	public  Set<String> keys(final String patten) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		Set<byte[]> set = jedis.keys(patten.getBytes());
		jedis.close();
		return fromByteToString(set);
	}

	public  long scard(final String key) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		long rel = jedis.scard(key.getBytes());
		jedis.close();
		return rel;
	}

	public  boolean sismember(final String key, final String mem) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		Boolean rel = jedis.sismember(key.getBytes(), mem.getBytes());
		return rel;
	}

	public  Set<String> hkeys(final String key) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		Set<byte[]> set = jedis.hkeys(key.getBytes());
		jedis.close();
		return fromByteToString(set);
	}

	public  void srem(final String key, final String mem) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		jedis.srem(key.getBytes(), mem.getBytes());
		jedis.close();
	}

	public  String type(final String key) {
		String type = "none";
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		type = jedis.type(key.getBytes());
		jedis.close();
		return type;
	}

	public  Boolean hdel(final String key, final String hkey) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		Long rel = jedis.hdel(key.getBytes(), hkey.getBytes());
		jedis.close();
		return (1 == rel.intValue()) ? true : false;
	}

	public  void expire(final String key, final long seconds) {
		Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);
		jedis.expireAt(key.getBytes(), seconds);
		jedis.close();
	}


	public  void main(String[] args) {
		//set("case:123456789","[\"001221\"]");

		//System.out.println(hGetAll("case:"));
		/*Jedis jedis = jedisPool.getResource();
		jedis.select(redis_server_dbid);*/


		Set keys = keys("case:*");
		Iterator<String> it = keys.iterator();
		while (it.hasNext()) {
			String str = it.next();
			System.out.println(str);
		}


	}
}
